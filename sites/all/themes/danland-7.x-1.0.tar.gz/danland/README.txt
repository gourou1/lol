Superfish Drop Menu:

1) Build a standard drupal menu. Set the correct levels to "expanded" (the parent item).

2) Disable Main menu in the Danland theme settings.
	 
3) Place the Main menu block in the Superfish menu region. Your menu will be automatically rendered as a Drop menu.
	 
4) To modify the animation style and speed please see the following site for a full run down on configuring the Superfish plugin: http://users.tpg.com.au/j_birch/plugins/superfish/